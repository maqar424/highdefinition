import json

def handler(event, context):
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*' # Wichtig für Frontend-Zugriff!
        },
        'body': json.dumps({'message': 'Hallo vom AWS Backend!'})
    }